<footer class="width-fluid">
  <p>Copyright &#169;  2018 yanbytes </p>
</footer>
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/font-awesome.min.css" />
 <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/font-awesome.css" />
 <script src="<?php echo base_url(); ?>assets/js/custom-script.js"></script>   
<script>
$('#vendor').selectize({
sortField: 'text'
});
$('#maincate').selectize({
sortField: 'text'
});
$('#category').selectize({
sortField: 'text'
});
$('#services').selectize({
sortField: 'text'
});
$('#cities').selectize({
sortField: 'text'
});
$('#vendor_sp').selectize({
sortField: 'text',
allowEmptyOption: false
});
</script>
</body>
</html>